INSERT INTO CATEGORY VALUES (1, 'CODING');
INSERT INTO CATEGORY VALUES (2, 'METEOROLOGY');
INSERT INTO CATEGORY VALUES (3, 'LITERATURE');

Insert into FLASHCARD (FLASHCARD_ID,ANSWER,QUESTION,CATEGORY_ID) values (8,'In the corner, it''s 90 degrees.','Where do you stand if you''re cold?',2);
Insert into FLASHCARD (FLASHCARD_ID,ANSWER,QUESTION,CATEGORY_ID) values (23,'AWESOME and automagical','What is Spring MVC?',1);
Insert into FLASHCARD (FLASHCARD_ID,ANSWER,QUESTION,CATEGORY_ID) values (1,'The best language','What is Java?',1);
Insert into FLASHCARD (FLASHCARD_ID,ANSWER,QUESTION,CATEGORY_ID) values (2,'not right now... maybe','Is it raining?',2);
Insert into FLASHCARD (FLASHCARD_ID,ANSWER,QUESTION,CATEGORY_ID) values (4,'Java 8','What is the answer to life, the universe, and everything?',1);
Insert into FLASHCARD (FLASHCARD_ID,ANSWER,QUESTION,CATEGORY_ID) values (6,'42','What is the answer to life, the universe, and everything?',1);
Insert into FLASHCARD (FLASHCARD_ID,ANSWER,QUESTION,CATEGORY_ID) values (22,'What is your quest?','To find the Holy Grail',3);

COMMIT;