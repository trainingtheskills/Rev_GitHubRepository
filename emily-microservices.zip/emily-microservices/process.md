## How to use these examples:

# Cloud versioning
These are built to work with Spring Cloud Finchley and Spring Boot 2+. 
The annotations and dependency names are a bit different than earlier versions. 

# Eureka Server
First, spin up the Eureka server (flashcard-discovery). This does not rely on any other services to run. 
Explain its role within the MSA, and how other services send a heartbeat to register themselves. 
Show the Eureka web console at localhost:8761. 

# Flashcard Service
This is a simple Spring Boot app with H2 embedded database (console enabled). 
In the present form, the application.properties files are at https://github.com/1807July30Java/vigilant-couscous. 
The properties are being fetched by the config server but in the first demo, I recommend adding the config locally. 
Spin these up in addition to Eureka and show how they register themselves in the console and at /eureka/apps. 

# Config Server
Once the discovery and flashcard services are up, add flashcard-service.properties (or .yml) to a repo of your choice.
The current version uses a public GitHub repo for convenience, but you can use a private GitLab repo (also free). 
Sensitive credentials can be included as environment variables, e.g. 
`spring.cloud.config.server.git.uri=${ENVIRONMENT VARIABLE NAME}`
`spring.cloud.config.server.git.username=${ENVIRONMENT VARIABLE NAME}`
`spring.cloud.config.server.git.password=${ENVIRONMENT VARIABLE NAME}`

# Zuul Gateway
To demonstrate Zuul, first start up flashcard-gateway and show the /actuator/routes/ endpoint. 
Show the mapping to another site of your choice via the test endpoint, then the routing to services in the ecosystem.
Start with routing by physical location, then by service ID (this must correspond to spring.application.name).

# Hystrix fallback methods
To demonstrate Hystrix fallbacks, the flashcard-hystrix application makes a call with RestTemplate to the flashcard service.
Make the call with the flashcard-service running, then kill it and make the call again. 
Show that the fallback method provided a dummy list of data. 

## Some good resources:
[Lastest Spring Cloud docs](http://cloud.spring.io/spring-cloud-static/Finchley.SR1/single/spring-cloud.html)
[DZone tutorial](https://dzone.com/articles/quick-guide-to-microservices-with-spring-boot-20-e)
[spring.io tutorial](https://spring.io/guides/gs/service-registration-and-discovery/)
[The Hidden Manual](https://blog.asarkar.org/technical/netflix-eureka/)


