package com.revature.flashcard2.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.flashcard2.bean.FlashCard;

@RestController
public class FlashCardCtrl2 {

	@GetMapping("/getFc")
	public FlashCard getFc(){
		System.out.println("fc2 -getmapping");
		return new FlashCard(1, "What is Java?", "Coffe");
	}
	
}
